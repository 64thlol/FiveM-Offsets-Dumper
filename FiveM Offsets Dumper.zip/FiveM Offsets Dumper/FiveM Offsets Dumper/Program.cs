using System;using System.Collections.Generic;using System.Diagnostics;using System.Linq;using System.Runtime.InteropServices;
namespace a{
class P{public string n,s;public int o;public P(string a,string b,int c){n=a;s=b;o=c;}}
class X{
[DllImport("kernel32")]public static extern bool ReadProcessMemory(IntPtr a,IntPtr b,byte[] c,int d,out IntPtr e);
[DllImport("kernel32")]public static extern IntPtr OpenProcess(int a,bool b,int c);
[DllImport("kernel32")]public static extern int VirtualQueryEx(IntPtr a,IntPtr b,out M c,uint d);
[DllImport("kernel32")]static extern IntPtr GetStdHandle(int a);
[DllImport("kernel32")]static extern bool GetConsoleMode(IntPtr a,out uint b);
[DllImport("kernel32")]static extern bool SetConsoleMode(IntPtr a,uint b);
public struct M{public ulong a,b;public uint c,d;public ulong e;public uint f,g,h,i;}
static void g(string t,int r,int g,int b,int r2,int g2,int b2,bool l=true){
for(int i=0;i<t.Length;i++){
float p=(float)i/(t.Length>1?t.Length-1:1);
Console.Write($"\x1b[38;2;{(int)(r+(r2-r)*p)};{(int)(g+(g2-g)*p)};{(int)(b+(b2-b)*p)}m{t[i]}");
}if(l)Console.WriteLine("\x1b[0m");else Console.Write("\x1b[0m");}
static void Main(){
var h=GetStdHandle(-11);GetConsoleMode(h,out uint m);SetConsoleMode(h,m|4);
Console.Title="";Console.Clear();Console.WriteLine();
g("    Educational Purpases ONLY!!",255,0,0,100,0,0);
g("    [+] FiveM Offset Dumper Made by @bigbertha__ on discord",0,255,255,0,100,255);
g("    ========================================================",255,255,255,100,100,100);
var ps=Process.GetProcesses().Where(x=>x.ProcessName.Contains("GTAProcess")||x.ProcessName.Contains("FiveM")||x.ProcessName.ToLower()=="gta5").ToList();
if(ps.Count==0){g("    Could not find FiveM.",255,0,0,100,0,0);Console.ReadLine();return;}
var tp=ps.OrderByDescending(x=>x.WorkingSet64).First();
IntPtr ba=tp.MainModule.BaseAddress,ph=OpenProcess(1040,false,tp.Id);
int ms=tp.MainModule.ModuleMemorySize;
if(ph==IntPtr.Zero){g("    Failed handle.",255,0,0,100,0,0);Console.ReadLine();return;}
byte[] mm=new byte[ms];IntPtr br;long ca=ba.ToInt64(),ea=ca+ms;
while(ca<ea){M mi;if(VirtualQueryEx(ph,(IntPtr)ca,out mi,(uint)Marshal.SizeOf(typeof(M)))==0)break;
long rs=(long)mi.e;if(ca+rs>ea)rs=ea-ca;
if(mi.f==4096&&(mi.g&256)==0&&(mi.g&1)==0){
byte[] bf=new byte[rs];if(ReadProcessMemory(ph,(IntPtr)ca,bf,(int)rs,out br))
Buffer.BlockCopy(bf,0,mm,(int)(ca-ba.ToInt64()),(int)br);}
ca+=(long)mi.e;}
var pt=new List<P>{
new P("camera","4C 8B 35 ? ? ? ? 33 FF 32 DB",3),new P("replay_interface","48 8D 0D ? ? ? ? 48 ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 84 C0 74 BC 8B 8F",3),
new P("world","48 8B 05 ? ? ? ? 33 D2 48 8B 40 08 8A CA 48 85 C0 74 16 48 8B",3),new P("viewport","48 8B 15 ? ? ? ? 48 8D 2D ? ? ? ? 48 8B CD",3),
new P("blip_list","4C 8D 05 ? ? ? ? 0F B7 C1",3),new P("bullet","F3 41 0F 10 19 F3 41 0F 10 41 04",3),
new P("c_sky_settings","48 8D 0D ? ? ? ? E8 ? ? ? ? 83 25 ? ? ? ? 00 48 8D 0D ? ? ? ? F3",3),
new P("aim_cped","48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8B 0D ? ? ? ? 48 85 C9 74 05 E8 ? ? ? ? 8A CB",3),
new P("set_ped_in_to_vehicle","48 8B C4 44 89 48 ? 44 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 83 BA",3),
new P("WorldPtr_Primary", "48 8B 05 ?? ?? ?? ?? 45 ?? ?? ?? ?? 48 8B 48 08", 3),new P("WorldPtr_Alt1", "48 8B 05 ?? ?? ?? ?? 48 8B 48 08 48 85 C9", 3),
new P("WorldPtr_Alt2", "48 8B 05 ?? ?? ?? ?? 48 85 C0 74 ?? 48 8B 48 08", 3),new P("BlipPtr_Primary", "4C 8D 05 ?? ?? ?? ?? 0F B7 C1", 3),
new P("BlipPtr_Alt1", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 0F B7 C2", 3),new P("GlobalPtr_Primary", "4C 8D 05 ?? ?? ?? ?? 4D 8B 08 4D 85 C9 74 11", 3),
new P("GlobalPtr_Alt1", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 48 8B 01", 3),new P("PedPool_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 8B 41 10", 3),
new P("PedPool_Alt1", "48 8B 05 ?? ?? ?? ?? 48 85 C0 74 ?? 48 8B 08", 3),new P("VehiclePool_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 8B 41 08", 3),
new P("VehiclePool_Alt1", "4C 8B 05 ?? ?? ?? ?? 48 8B D9 48 85 C0", 3),new P("ObjectPool_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 44 8B 41 10", 3),
new P("PickupPool_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 48 8B 01 FF 50", 3),new P("CameraManager_Primary", "48 8B 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 85 C0 74", 3),
new P("CameraManager_Alt1", "48 8B 05 ?? ?? ?? ?? 48 85 C0 74 ?? F3 0F 10 40 60", 3),new P("GameState_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 8B 41 ?? C3", 3),
new P("ReplayInterface_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? 48 8B 01 FF 90", 3),new P("NetworkManager_Primary", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? E8 ?? ?? ?? ??", 3),
new P("ReadPositionX", "F3 0F 10 80 90 00 00 00", 0),new P("ReadPositionY", "F3 0F 10 80 94 00 00 00", 0),
new P("ReadPositionZ", "F3 0F 10 80 98 00 00 00", 0),new P("WritePositionX", "F3 0F 11 81 90 00 00 00", 0),
new P("WritePositionY", "F3 0F 11 81 94 00 00 00", 0),new P("WritePositionZ", "F3 0F 11 81 98 00 00 00", 0),
new P("ReadHealth", "F3 0F 10 80 80 02 00 00", 0),new P("WriteHealth", "F3 0F 11 81 80 02 00 00", 0),
new P("ReadMaxHealth", "F3 0F 10 80 A0 02 00 00", 0),new P("GodmodeCheck", "80 B8 89 01 00 00 00", 0),
new P("GodmodeSet", "C6 81 89 01 00 00 01", 0),new P("GetCurrentVehicle", "48 8B 80 28 0D 00 00", 0),
new P("InVehicleCheck", "8B 80 44 0E 00 00", 0),new P("VehicleGravity", "F3 0F 11 81 1C 0C 00 00", 0),
new P("VehicleSpeed", "F3 0F 10 80 80 0A 00 00", 0),new P("GetWeaponManager", "48 8B 81 C8 10 00 00", 0),
new P("WeaponDamage", "F3 0F 11 81 B0 00 00 00", 0),new P("WeaponRecoil", "F3 0F 10 80 E8 02 00 00", 0),
new P("WeaponSpread", "F3 0F 10 80 74 00 00 00", 0),new P("WorldProbe", "48 89 5C 24 ?? 48 89 6C 24 ?? 48 89 74 24 ?? 57 41 54 41 55 41 56 41 57 48 83 EC 60", 0),
new P("LineOfSight", "48 89 5C 24 ?? 48 89 74 24 ?? 57 48 83 EC 40 F3 0F 10 02", 0),new P("ShapeTest", "40 53 48 83 EC 30 0F 29 74 24 ?? 0F 28 F1 48 8B D9", 0),
new P("IntersectRay", "48 89 5C 24 ?? 57 48 83 EC 20 48 8B FA 48 8B D9 E8", 0),new P("CheckVisible", "80 B8 2C 00 00 00 00 74", 0),
new P("CheckOccluded", "80 B8 2D 00 00 00 00 75", 0),new P("CheckInFrustum", "80 B8 2E 00 00 00 00 74", 0),
new P("IgnoreCollision", "C6 81 2E 00 00 00 01", 0),new P("CollisionFlags", "8B 80 2C 00 00 00", 0),
new P("WorldCollision", "48 8B 0D ?? ?? ?? ?? 48 85 C9 74 ?? E8 ?? ?? ?? ?? 84 C0", 3),new P("GetAimTarget", "48 8B 80 D0 10 00 00", 0),
new P("SetAimTarget", "48 89 81 D0 10 00 00", 0),new P("LockOnTarget", "48 8B 80 D8 10 00 00", 0),
new P("AimAssist", "F3 0F 10 80 E8 10 00 00", 0),new P("GetBoneMatrix", "48 8B 80 30 04 00 00", 0),
new P("GetBoneCount", "8B 80 38 04 00 00", 0),new P("GetBonePos", "48 89 5C 24 ?? 57 48 83 EC 20 8B FA 48 8B D9 E8 ?? ?? ?? ??", 0),
new P("MovRaxGlobal", "48 8B 05 ?? ?? ?? ??", 3),new P("MovRcxGlobal", "48 8B 0D ?? ?? ?? ??", 3),
new P("MovRdxGlobal", "48 8B 15 ?? ?? ?? ??", 3),new P("MovRbxGlobal", "48 8B 1D ?? ?? ?? ??", 3),
new P("MovR8Global", "4C 8B 05 ?? ?? ?? ??", 3),new P("MovR9Global", "4C 8B 0D ?? ?? ?? ??", 3),
new P("LeaRaxGlobal", "48 8D 05 ?? ?? ?? ??", 3),new P("LeaRcxGlobal", "48 8D 0D ?? ?? ?? ??", 3),
new P("LeaRdxGlobal", "48 8D 15 ?? ?? ?? ??", 3),new P("ReadQwordPtr", "48 8B 80 ?? ?? ?? ?? 48 85 C0", 0),
new P("ReadQwordPtr2", "48 8B 88 ?? ?? ?? ?? 48 85 C9", 0),new P("ReadDword", "8B 80 ?? ?? ?? ?? 85 C0", 0),
new P("ReadFloat", "F3 0F 10 80 ?? ?? ?? ??", 0),new P("WriteFloat", "F3 0F 11 81 ?? ?? ?? ??", 0),
new P("ReadByte", "0F B6 80 ?? ?? ?? ??", 0),new P("WriteByte", "C6 81 ?? ?? ?? ?? ??", 0),
new P("CallGlobalFunc", "E8 ?? ?? ?? ?? 48 85 C0 74", 1),new P("CallVirtual", "48 8B 01 FF 90 ?? ?? ?? ??", 0),
new P("JmpGlobalFunc", "E9 ?? ?? ?? ?? CC CC CC", 1)};
string ojs="{\n";
foreach(var pt_ in pt){
string[] pr=pt_.s.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries);
byte[]b_=new byte[pr.Length];bool[]m_=new bool[pr.Length];
for(int i=0;i<pr.Length;i++){if(pr[i]=="??"||pr[i]=="?"){b_[i]=0;m_[i]=false;}else{b_[i]=Convert.ToByte(pr[i],16);m_[i]=true;}}
long rs=-1;int pl=b_.Length;int dl=mm.Length-pl;
for(int i=0;i<dl;i++){bool f=true;for(int j=0;j<pl;j++){if(m_[j]&&mm[i+j]!=b_[j]){f=false;break;}}if(f){rs=i;break;}}
g($"    {pt_.n,-30}",255,255,255,200,200,200,false);
if(rs!=-1){
long aa=ba.ToInt64()+rs;if(pt_.o>0){byte[] ob=new byte[4];Buffer.BlockCopy(mm,(int)rs+pt_.o,ob,0,4);
long ro=BitConverter.ToInt32(ob,0);long ra=aa+pt_.o+4+ro;long ofx=ra-ba.ToInt64();
g($"0x{ofx:X}",0,255,255,0,100,255);ojs+=$"  \"{pt_.n}\": \"0x{ofx:X}\",\n";}else{g($"0x{rs:X}",0,255,255,0,100,255);ojs+=$"  \"{pt_.n}\": \"0x{rs:X}\",\n";}
}else{g("Not Found",255,0,0,150,0,0);ojs+=$"  \"{pt_.n}\": \"Not Found\",\n";}}
ojs=ojs.TrimEnd(',','\n')+"\n}";
Console.WriteLine("\n");g("    Would you like to save resaults? Y/N",255,255,0,255,100,0);
Console.Write("    > ");Console.ForegroundColor=ConsoleColor.Yellow;var kp=Console.ReadLine();Console.ResetColor();
if(kp!=null&&kp.Trim().ToUpper()=="Y"){
try{System.IO.File.WriteAllText("offsets.json",ojs);g("    Saved successfully to offsets.json!",0,255,0,0,100,0);}
catch{g("    Failed to save json.",255,0,0,100,0,0);}
}
Console.WriteLine();g("    [+] Press Enter to exit...",0,255,255,0,100,255);Console.ReadLine();
}}}
